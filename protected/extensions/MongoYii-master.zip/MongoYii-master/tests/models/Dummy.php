<?php
class Dummy extends EMongoModel{

	public $dum;
	
	function rules(){
		return array();
	}

}