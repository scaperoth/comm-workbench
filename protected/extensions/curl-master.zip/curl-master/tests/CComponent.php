<?php

/**
* CCompoment Mock
*/
class CComponent
{
  function __construct()
  {
    $this->init();
  }
}